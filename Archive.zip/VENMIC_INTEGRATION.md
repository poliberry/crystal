# Venmic Integration Summary

This document summarizes the venmic integration into Crystal Electron.

## What Was Done

### 1. Electron Builder Configuration
- **Updated `electron-builder.yml`**: Added venmic to `asarUnpack` so the native addon is extracted from the ASAR archive (native modules cannot be loaded from within ASAR)

### 2. Package Configuration
- **Added `electron-rebuild`**: Added as a dev dependency to rebuild native modules for Electron
- **Added build scripts**:
  - `rebuild`: Manually rebuild venmic for Electron
  - `postinstall`: Automatically rebuilds venmic after `npm install`

### 3. Linux Audio Handler Improvements
- **Module initialization**: Added async initialization function that:
  - Tries to load venmic first
  - Checks PipeWire availability before using venmic
  - Falls back to pw-loopback if venmic is unavailable
  - Provides better error messages and logging

- **Error handling**: Improved error handling throughout:
  - Checks if modules are initialized before use
  - Provides clear error messages
  - Graceful fallbacks

- **Logging**: Added consistent logging with `[Linux Audio]` prefix for easier debugging

### 4. Venmic Integration File
- **Already updated**: The `venmic.ts` file was previously updated to:
  - Use the PatchBay API correctly
  - Set virtual mic name to "crystal-screen-share"
  - Handle singleton instance loading
  - Export `hasPipeWire()` function

## How It Works

### Module Loading Flow

1. **On app start**: `linux.ts` tries to initialize audio modules
2. **Load venmic**: Attempts to require `./venmic` module
3. **Check PipeWire**: Calls `hasPipeWire()` to verify PipeWire is available
4. **Use venmic**: If PipeWire is available, uses venmic for audio capture
5. **Fallback**: If venmic fails, falls back to pw-loopback implementation

### Audio Capture Flow

1. **User starts screen share**: IPC handler receives `AUDIO_START_CAPTURE` event
2. **Initialize modules**: Ensures audio modules are loaded
3. **Create virtual mic**: Calls `createVirtualMic()` with options:
   - `mode: "system"` for entire system audio
   - `mode: "selective"` for specific applications
4. **Wait for device**: Waits for virtual mic to be registered (500ms for venmic, 1000ms for pw-loopback)
5. **Return success**: Returns `{ ok: true }` when ready

### Virtual Microphone

- **Name**: "crystal-screen-share"
- **Type**: PipeWire null sink
- **Channels**: Stereo (FL, FR)
- **Usage**: Appears as an audio input device that can be selected in the web app

## Building and Packaging

### Development

```bash
# Install dependencies (will rebuild venmic automatically)
npm install

# Build the app
npm run build

# Run in development
npm run dev
```

### Production Build

```bash
# Package for distribution
npm run package
```

The packaged app will include:
- Venmic native addon (unpacked from ASAR)
- All necessary dependencies
- Properly rebuilt for Electron's Node version

## Testing

### Verify Venmic is Working

1. **Check console logs** when starting the app:
   ```
   [Linux Audio] Using @vencord/venmic for virtual microphone (PipeWire detected)
   ```

2. **Test audio capture**:
   - Start screen sharing with audio
   - Check if "crystal-screen-share" appears in audio input devices
   - Verify audio is being captured

3. **Enable debug logging**:
   ```bash
   export VENMIC_ENABLE_LOG=1
   npm run dev
   ```
   Check logs in `~/.local/state/venmic/venmic.log`

## Troubleshooting

### Venmic Not Loading

**Symptoms**: Console shows "venmic not available, falling back to pw-loopback"

**Solutions**:
1. Check if venmic is installed: `ls node_modules/@vencord/venmic`
2. Rebuild for Electron: `npm run rebuild`
3. Check for native addon: `find node_modules/@vencord/venmic -name "*.node"`

### PipeWire Not Detected

**Symptoms**: "venmic loaded but PipeWire not detected"

**Solutions**:
1. Check PipeWire is running: `systemctl --user status pipewire`
2. Install PipeWire if missing (see BUILD_INSTRUCTIONS.md)
3. Check PulseAudio compatibility layer is working

### Build Errors

**Symptoms**: `npm install` fails or `npm run rebuild` fails

**Solutions**:
1. Install build dependencies (CMake, C++ compiler, development libraries)
2. See BUILD_INSTRUCTIONS.md for platform-specific instructions
3. Check compiler version supports C++20

## Files Modified

1. `electron-builder.yml` - Added venmic to asarUnpack
2. `package.json` - Added electron-rebuild and build scripts
3. `src/main/audio/linux.ts` - Improved module loading and error handling
4. `src/main/audio/venmic.ts` - Already updated (uses PatchBay API correctly)

## Next Steps

1. **Test the integration**:
   - Run `npm install` to ensure venmic builds
   - Test screen sharing with audio capture
   - Verify virtual microphone appears

2. **Package and test**:
   - Run `npm run package` to create distributable
   - Test the packaged app on a clean system

3. **Monitor for issues**:
   - Check console logs for any errors
   - Enable venmic logging if needed
   - Report any issues with full error messages

## Notes

- Venmic only works on Linux with PipeWire
- The integration gracefully falls back to pw-loopback if venmic fails
- All native modules are automatically unpacked during packaging
- The virtual microphone name is "crystal-screen-share" to match app expectations

