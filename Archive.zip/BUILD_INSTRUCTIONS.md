# Building Crystal Electron with Venmic

This document explains how to build and bundle venmic with your Electron app.

## Prerequisites

### For Development
- Node.js 14.15 or higher
- npm or pnpm
- CMake 3.21 or higher (for building venmic native addon)
- C++20 compatible compiler (GCC 10+, Clang 12+)
- PipeWire development libraries (Linux only)
- PulseAudio development libraries (Linux only)

### Installing System Dependencies (Linux)

```bash
# Ubuntu/Debian
sudo apt-get install \
  build-essential \
  cmake \
  libpipewire-0.3-dev \
  libpulse-dev \
  pkg-config

# Fedora
sudo dnf install \
  gcc-c++ \
  cmake \
  pipewire-devel \
  pulseaudio-libs-devel \
  pkgconfig

# Arch Linux
sudo pacman -S \
  base-devel \
  cmake \
  pipewire \
  pulseaudio \
  pkgconf
```

## Installation Steps

### 1. Install Dependencies

```bash
cd /Users/user/Documents/GitHub/crystal-electron
npm install
```

This will:
- Install all npm dependencies including `@vencord/venmic`
- Run `postinstall` script which rebuilds venmic for Electron
- Build the native addon for your Electron version

### 2. Rebuild Native Modules (if needed)

If you need to manually rebuild venmic for Electron:

```bash
npm run rebuild
```

Or specifically for venmic:

```bash
npx electron-rebuild -f -w @vencord/venmic
```

### 3. Build the Application

```bash
# Build TypeScript and preload
npm run build

# Or build individually
npm run build:main
npm run build:preload
```

### 4. Development

```bash
# Run in development mode (with hot reload)
npm run dev

# Or build and run
npm run start:dev
```

### 5. Package for Distribution

```bash
npm run package
```

This will create distributable packages in the `dist/` directory.

## How Venmic is Bundled

### Electron Builder Configuration

The `electron-builder.yml` file is configured to:

1. **Unpack venmic from ASAR**: Native addons cannot be loaded from within ASAR archives, so venmic is unpacked:
   ```yaml
   asarUnpack:
     - "**/node_modules/@vencord/venmic/**/*"
   ```

2. **Include in build**: The native addon (`.node` file) is automatically included when packaging.

### Native Module Rebuilding

The `postinstall` script ensures venmic is rebuilt for Electron's Node.js version:

```json
"postinstall": "electron-rebuild -f -w @vencord/venmic || true"
```

The `|| true` ensures the build doesn't fail if electron-rebuild isn't available (it will be installed as a dev dependency).

## Troubleshooting

### Venmic Not Loading

1. **Check if venmic is installed**:
   ```bash
   ls node_modules/@vencord/venmic
   ```

2. **Check if native addon exists**:
   ```bash
   find node_modules/@vencord/venmic -name "*.node"
   ```

3. **Rebuild for Electron**:
   ```bash
   npm run rebuild
   ```

### PipeWire Not Detected

1. **Check if PipeWire is running**:
   ```bash
   systemctl --user status pipewire
   ```

2. **Check PipeWire version**:
   ```bash
   pw-cli --version
   ```

3. **Enable venmic logging** (set environment variable):
   ```bash
   export VENMIC_ENABLE_LOG=1
   npm run dev
   ```
   Logs will be in `~/.local/state/venmic/venmic.log`

### Build Errors

1. **CMake not found**:
   - Install CMake 3.21 or higher
   - Ensure it's in your PATH

2. **Missing development libraries**:
   - Install PipeWire and PulseAudio development packages (see Prerequisites)

3. **Compiler errors**:
   - Ensure you have a C++20 compatible compiler
   - Check compiler version: `g++ --version` or `clang++ --version`

### Runtime Errors

1. **"Module not found"**:
   - Ensure venmic is in `node_modules/@vencord/venmic`
   - Run `npm install` again

2. **"Cannot load native addon"**:
   - The addon must be rebuilt for Electron's Node version
   - Run `npm run rebuild`

3. **"PipeWire not available"**:
   - Ensure PipeWire is installed and running
   - Check with: `pw-cli info`

## Using Local Venmic Development

If you're developing venmic locally and want to use it in crystal-electron:

1. **Link the local venmic**:
   ```bash
   cd /Users/user/Downloads/venmic-main
   npm link
   
   cd /Users/user/Documents/GitHub/crystal-electron
   npm link @vencord/venmic
   ```

2. **Rebuild for Electron**:
   ```bash
   npm run rebuild
   ```

## Verification

To verify venmic is working:

1. **Check logs** when starting the app - you should see:
   ```
   [Linux Audio] Using @vencord/venmic for virtual microphone (PipeWire detected)
   ```

2. **Test audio capture**:
   - Start screen sharing with audio
   - Check if "crystal-screen-share" appears in audio input devices
   - Verify audio is being captured

## Notes

- Venmic only works on Linux with PipeWire
- The virtual microphone name is set to "crystal-screen-share"
- Venmic falls back to pw-loopback if the native addon fails to load
- All native modules are automatically unpacked from ASAR during packaging

