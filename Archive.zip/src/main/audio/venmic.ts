/*
 * Venmic Integration
 * Uses @vencord/venmic native addon for PipeWire virtual microphone
 * This provides a stable native implementation for PipeWire audio capture
 */

//import type { Node, LinkData } from "crystal-virtmic";

// venmic is a native addon, so we need to require it dynamically
let venmic: any = null;
let patchBayInstance: any = null;
let venmicAvailable = false;

const VIRTUAL_MIC_NAME = "crystal-screen-share";

try {
  const venmicModule = require("crystal-virtmic");
  
  // venmic exports PatchBay class and singleton instance
  // Try to get the singleton instance first (default export)
  if (venmicModule.default) {
    patchBayInstance = venmicModule.default;
  } else if (venmicModule.instance) {
    patchBayInstance = venmicModule.instance;
  } else if (venmicModule.PatchBay) {
    // If no singleton, create an instance (it uses singleton internally)
    patchBayInstance = new venmicModule.PatchBay();
  }
  
  venmic = venmicModule;
  
  // Verify we have a working PatchBay instance
  if (patchBayInstance && typeof patchBayInstance.list === 'function') {
    // Set the virtual mic name before first use
    if (typeof patchBayInstance.setVirtualMicName === 'function') {
      patchBayInstance.setVirtualMicName(VIRTUAL_MIC_NAME);
    }
    venmicAvailable = true;
    console.log("venmic loaded successfully, virtual mic name set to:", VIRTUAL_MIC_NAME);
  } else {
    console.warn("venmic loaded but PatchBay instance is not available");
    venmicAvailable = false;
  }
} catch (error) {
  console.warn("Failed to load @vencord/venmic:", error);
  venmicAvailable = false;
}

export interface AudioNode {
  "application.name"?: string;
  "application.process.id"?: string;
  "node.name"?: string;
  "media.class"?: string;
  "media.name"?: string;
  "device.id"?: string;
  [key: string]: string | undefined;
}

export interface VirtualMicOptions {
  mode: "system" | "selective";
  include?: AudioNode[];
  exclude?: AudioNode[];
}

let virtualMicActive = false;

/**
 * Check if venmic is available
 */
function checkVenmicAvailable(): boolean {
  return venmicAvailable && patchBayInstance !== null;
}

/**
 * Check if PipeWire is available on the system
 */
export async function hasPipeWire(): Promise<boolean> {
  try {
    if (!checkVenmicAvailable()) {
      return false;
    }
    
    if (typeof venmic.PatchBay?.hasPipeWire === 'function') {
      return venmic.PatchBay.hasPipeWire();
    }
    
    return false;
  } catch (error) {
    console.error("Error checking PipeWire availability:", error);
    return false;
  }
}

/**
 * List available audio sources using venmic
 */
export async function listAudioSources(): Promise<AudioNode[]> {
  try {
    if (!checkVenmicAvailable()) {
      console.warn("venmic not available");
      return [];
    }

    // PatchBay.list() returns an array of Node objects
    const nodes = patchBayInstance.list([
      "application.name",
      "node.name",
      "application.process.id",
      "media.class",
      "device.id"
    ]);
    
    if (Array.isArray(nodes)) {
      return nodes as AudioNode[];
    }
    
    return [];
  } catch (error) {
    console.error("Error listing audio sources via venmic:", error);
    return [];
  }
}

/**
 * Create a virtual microphone using venmic
 */
export async function createVirtualMic(options: VirtualMicOptions): Promise<void> {
  if (virtualMicActive) {
    await stopVirtualMic();
  }

  try {
    if (!checkVenmicAvailable()) {
      throw new Error("@vencord/venmic is not available. Please install it: npm install @vencord/venmic");
    }

    console.log("Creating virtual microphone using venmic:", VIRTUAL_MIC_NAME);

    // Ensure virtual mic name is set
    if (typeof patchBayInstance.setVirtualMicName === 'function') {
      patchBayInstance.setVirtualMicName(VIRTUAL_MIC_NAME);
    }

    // Build link options based on mode
    const linkOptions: any = {
      include: [],
      exclude: [],
      ignore_devices: true,
      only_speakers: true,
      only_default_speakers: true,
      workaround: []
    };

    if (options.mode === "system") {
      // For system mode, don't specify include - it will capture all by default
      // But we can exclude specific sources
      if (options.exclude && options.exclude.length > 0) {
        linkOptions.exclude = options.exclude as any[];
      }
      // When include is empty and only_default_speakers is true, it captures system audio
      console.log("Starting system audio capture with exclusions:", linkOptions.exclude.length);
    } else if (options.mode === "selective" && options.include) {
      // For selective mode, specify which sources to include
      linkOptions.include = options.include as any[];
      if (options.exclude && options.exclude.length > 0) {
        linkOptions.exclude = options.exclude as any[];
      }
      // For selective mode, we might want to disable only_default_speakers
      linkOptions.only_default_speakers = false;
      console.log("Starting selective audio capture with", linkOptions.include.length, "sources");
    } else {
      throw new Error("Invalid virtual mic options: selective mode requires include sources");
    }

    // Call link with the options
    patchBayInstance.link(linkOptions);
    
    virtualMicActive = true;
    
    // Wait for the device to be registered
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    console.log("Virtual microphone created successfully using venmic");
  } catch (error) {
    console.error("Error creating virtual microphone with venmic:", error);
    virtualMicActive = false;
    try {
      patchBayInstance.unlink();
    } catch (stopError) {
      console.warn("Error stopping venmic during cleanup:", stopError);
    }
    throw error;
  }
}

/**
 * Stop the virtual microphone and clean up resources
 */
export async function stopVirtualMic(): Promise<void> {
  if (!virtualMicActive && !patchBayInstance) {
    return;
  }

  try {
    if (patchBayInstance) {
      patchBayInstance.unlink();
      console.log("Stopped venmic virtual microphone");
    }

    virtualMicActive = false;
    console.log("Virtual microphone stopped");
  } catch (error) {
    console.error("Error stopping virtual microphone:", error);
    // Reset state even if cleanup fails
    virtualMicActive = false;
  }
}

/**
 * Check if venmic is available on the system
 */
export async function isVenmicAvailable(): Promise<boolean> {
  return checkVenmicAvailable();
}
