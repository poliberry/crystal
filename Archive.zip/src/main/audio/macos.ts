/*
 * macOS Audio Handler
 * Uses Electron's native loopback audio (macOS 13+)
 */

import { ipcMain, session, desktopCapturer } from "electron";

interface IPCEvents {
  AUDIO_GET_SOURCES: string;
  AUDIO_START_CAPTURE: string;
  AUDIO_STOP_CAPTURE: string;
}

export function registerMacOSAudio(events: IPCEvents) {
  // macOS uses native loopback audio via getDisplayMedia (macOS 13+)
  ipcMain.handle(events.AUDIO_GET_SOURCES, async () => {
    try {
      // Check macOS version
      const os = require("os");
      const release = os.release();
      const darwinVersion = parseInt(release.split(".")[0]);
      
      // Darwin 22.x = macOS 13.x, Darwin 23.x = macOS 14.x
      // Native loopback requires macOS 13+
      if (darwinVersion < 22) {
        return {
          ok: true,
          sources: [
            { name: "System Audio (requires macOS 13+)", value: "system" }
          ],
          requiresUpdate: true,
          minVersion: "13.0",
          darwinVersion,
          macosVersion: `macOS ${darwinVersion >= 23 ? "14" : darwinVersion >= 22 ? "13" : "12 or earlier"}`
        };
      }

      return {
        ok: true,
        sources: [
          { name: "System Audio", value: "system" }
        ],
        darwinVersion,
        macosVersion: darwinVersion >= 23 ? "macOS 14+" : "macOS 13+"
      };
    } catch (error) {
      return { ok: false, error: String(error) };
    }
  });

  // Register display media handler - but we use custom picker, so this is just a fallback
  // useSystemPicker: false means we use Electron's custom picker instead of system picker
  session.defaultSession.setDisplayMediaRequestHandler(
    async (request: any, callback: any) => {
      try {
        // Get available sources
        const sources = await desktopCapturer.getSources({
          types: ["window", "screen"],
          thumbnailSize: { width: 176, height: 99 }
        });

        // This handler is only used as a fallback if getDisplayMedia is called directly
        // Our custom picker handles source selection, so this just grants access
        if (sources.length > 0) {
          console.log("Granting access to screen source (fallback handler)");
          callback({ 
            video: sources[0],
            // Don't specify audio here - we handle audio separately via virtual devices
          });
        } else {
          console.warn("No screen sources available");
          callback({});
        }
      } catch (error) {
        console.error("Error in macOS display media handler:", error);
        callback({});
      }
    },
    { useSystemPicker: false } // Use Electron's custom picker, not system picker
  );

  // Start audio capture - handled by getDisplayMedia in renderer
  ipcMain.handle(events.AUDIO_START_CAPTURE, async () => {
    // macOS audio is captured via getDisplayMedia with loopback
    // This is handled in the renderer process
    return { 
      ok: true, 
      message: "Audio capture handled by getDisplayMedia with native loopback"
    };
  });

  // Stop audio capture - handled automatically by Electron
  ipcMain.handle(events.AUDIO_STOP_CAPTURE, async () => {
    return { ok: true };
  });
}
