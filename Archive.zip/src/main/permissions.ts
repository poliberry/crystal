/*
 * Permissions Handler
 * Handles camera and microphone permission requests
 */

import { ipcMain, systemPreferences, desktopCapturer } from "electron";

const IPC_EVENTS = {
  PERMISSIONS_REQUEST_CAMERA: "crystal:permissions:request-camera",
  PERMISSIONS_REQUEST_MICROPHONE: "crystal:permissions:request-microphone",
  PERMISSIONS_REQUEST_BOTH: "crystal:permissions:request-both",
  PERMISSIONS_CHECK_CAMERA: "crystal:permissions:check-camera",
  PERMISSIONS_CHECK_MICROPHONE: "crystal:permissions:check-microphone",
  PERMISSIONS_CHECK_SCREEN_RECORDING: "crystal:permissions:check-screen-recording"
};

export function registerPermissionsHandler() {
  const platform = process.platform;

  // Request camera permission
  ipcMain.handle(IPC_EVENTS.PERMISSIONS_REQUEST_CAMERA, async () => {
    try {
      if (platform === "darwin") {
        // macOS requires explicit permission request
        const status = await systemPreferences.askForMediaAccess("camera");
        return { granted: status, platform: "darwin" };
      } else if (platform === "win32") {
        // Windows handles permissions automatically, but we can check status
        const status = systemPreferences.getMediaAccessStatus("camera");
        return { granted: status === "granted", platform: "win32", status };
      } else {
        // Linux typically doesn't require explicit permissions
        // Permissions are handled by the system when getUserMedia is called
        return { granted: true, platform: "linux" };
      }
    } catch (error) {
      console.error("Error requesting camera permission:", error);
      return { granted: false, error: String(error) };
    }
  });

  // Request microphone permission
  ipcMain.handle(IPC_EVENTS.PERMISSIONS_REQUEST_MICROPHONE, async () => {
    try {
      if (platform === "darwin") {
        // macOS requires explicit permission request
        const status = await systemPreferences.askForMediaAccess("microphone");
        return { granted: status, platform: "darwin" };
      } else if (platform === "win32") {
        // Windows handles permissions automatically, but we can check status
        const status = systemPreferences.getMediaAccessStatus("microphone");
        return { granted: status === "granted", platform: "win32", status };
      } else {
        // Linux typically doesn't require explicit permissions
        // Permissions are handled by the system when getUserMedia is called
        return { granted: true, platform: "linux" };
      }
    } catch (error) {
      console.error("Error requesting microphone permission:", error);
      return { granted: false, error: String(error) };
    }
  });

  // Request both camera and microphone permissions
  ipcMain.handle(IPC_EVENTS.PERMISSIONS_REQUEST_BOTH, async () => {
    try {
      if (platform === "darwin") {
        // macOS requires explicit permission requests
        const [cameraStatus, microphoneStatus] = await Promise.all([
          systemPreferences.askForMediaAccess("camera"),
          systemPreferences.askForMediaAccess("microphone")
        ]);
        return {
          camera: { granted: cameraStatus },
          microphone: { granted: microphoneStatus },
          platform: "darwin"
        };
      } else if (platform === "win32") {
        // Windows handles permissions automatically, but we can check status
        const cameraStatus = systemPreferences.getMediaAccessStatus("camera");
        const microphoneStatus = systemPreferences.getMediaAccessStatus("microphone");
        return {
          camera: { granted: cameraStatus === "granted", status: cameraStatus },
          microphone: { granted: microphoneStatus === "granted", status: microphoneStatus },
          platform: "win32"
        };
      } else {
        // Linux typically doesn't require explicit permissions
        return {
          camera: { granted: true },
          microphone: { granted: true },
          platform: "linux"
        };
      }
    } catch (error) {
      console.error("Error requesting permissions:", error);
      return {
        camera: { granted: false },
        microphone: { granted: false },
        error: String(error)
      };
    }
  });

  // Check camera permission status
  ipcMain.handle(IPC_EVENTS.PERMISSIONS_CHECK_CAMERA, async () => {
    try {
      if (platform === "darwin" || platform === "win32") {
        const status = systemPreferences.getMediaAccessStatus("camera");
        return { granted: status === "granted", status, platform };
      } else {
        // Linux doesn't have a status check API
        return { granted: true, platform: "linux" };
      }
    } catch (error) {
      console.error("Error checking camera permission:", error);
      return { granted: false, error: String(error) };
    }
  });

  // Check microphone permission status
  ipcMain.handle(IPC_EVENTS.PERMISSIONS_CHECK_MICROPHONE, async () => {
    try {
      if (platform === "darwin" || platform === "win32") {
        const status = systemPreferences.getMediaAccessStatus("microphone");
        return { granted: status === "granted", status, platform };
      } else {
        // Linux doesn't have a status check API
        return { granted: true, platform: "linux" };
      }
    } catch (error) {
      console.error("Error checking microphone permission:", error);
      return { granted: false, error: String(error) };
    }
  });

  // Check screen recording permission status (macOS only)
  ipcMain.handle(IPC_EVENTS.PERMISSIONS_CHECK_SCREEN_RECORDING, async () => {
    try {
      if (platform === "darwin") {
        // On macOS, the most reliable way to check screen recording permission
        // is to actually try to get sources. getMediaAccessStatus("screen") 
        // may not be reliable or available in all Electron versions.
        try {
          // Try to get sources - if this succeeds, permission is granted
          const sources = await desktopCapturer.getSources({
            types: ["screen"],
            thumbnailSize: { width: 1, height: 1 }
          });
          
          // If we got sources (even if empty), permission is likely granted
          // Empty sources might just mean no screens, not no permission
          return {
            granted: true,
            status: "granted",
            platform: "darwin"
          };
        } catch (testError: any) {
          // If getting sources fails, permission is likely not granted
          console.log("Screen recording permission test failed:", testError?.message);
          return {
            granted: false,
            status: "denied",
            platform: "darwin",
            message: "Screen recording permission is required. Please enable it in System Preferences > Security & Privacy > Screen Recording.",
            error: testError?.message
          };
        }
      } else if (platform === "win32") {
        // Windows doesn't require explicit screen recording permission
        return { granted: true, platform: "win32" };
      } else {
        // Linux uses xdg-desktop-portal which handles permissions automatically
        return { granted: true, platform: "linux" };
      }
    } catch (error) {
      console.error("Error checking screen recording permission:", error);
      // Return a safe response instead of throwing
      return { 
        granted: false, 
        error: String(error),
        platform: platform || "unknown",
        message: "Failed to check screen recording permission. Please ensure it's enabled in System Preferences."
      };
    }
  });
}

