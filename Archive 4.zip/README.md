# Crystal Electron Wrapper

Electron wrapper for Crystal web app with native screen sharing and system audio support.

## Features

- **Native Screen Sharing**: Select screens/windows to share
- **System Audio Capture**:
  - **Windows**: Native loopback audio via Electron APIs
  - **macOS**: System audio (requires loopback device like BlackHole)
  - **Linux**: Virtual microphone via PipeWire

## Setup

```bash
# Install dependencies
npm install

# Development
npm run dev

# Build
npm run build

# Start
npm start
```

## Architecture

- `src/main/`: Main Electron process
  - `index.ts`: Main entry point
  - `screenShare.ts`: Screen sharing IPC handlers
  - `screenSharePicker.ts`: Picker window management
  - `audio.ts`: Audio handler router
  - `audio/linux.ts`: Linux PipeWire audio
  - `audio/windows.ts`: Windows native audio
  - `audio/macos.ts`: macOS audio
  - `audio/pipewire.ts`: PipeWire virtual mic implementation

- `src/preload/`: Preload script exposing safe APIs
- `static/html/`: HTML files for picker windows

## IPC Events

### Screen Sharing
- `crystal:screen-share:get-sources`: Get available screens/windows
- `crystal:screen-share:open-picker`: Open picker window
- `crystal:screen-share:pick`: Submit picker choice
- `crystal:screen-share:cancel`: Cancel picker

### Audio
- `crystal:audio:get-sources`: Get audio sources (Linux only)
- `crystal:audio:start-capture`: Start audio capture
- `crystal:audio:stop-capture`: Stop audio capture

## Usage in Web App

```typescript
// Check if running in Electron
if (window.CrystalNative) {
  // Open screen share picker
  const choice = await window.CrystalNative.screenShare.openPicker();
  
  // Get video stream
  const videoStream = await navigator.mediaDevices.getUserMedia({
    video: {
      mandatory: {
        chromeMediaSource: 'desktop',
        chromeMediaSourceId: choice.id
      }
    } as any
  });
  
  // Handle audio based on platform
  if (window.CrystalNative.platform.isLinux()) {
    // Start virtual mic
    await window.CrystalNative.audio.startCapture({
      includeSources: choice.includeSources
    });
    
    // Capture from virtual mic
    const audioStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        deviceId: { exact: 'crystal-screen-share' }
      }
    });
  } else if (choice.audio) {
    // Windows/macOS: Use getDisplayMedia for audio
    const displayStream = await navigator.mediaDevices.getDisplayMedia({
      video: true,
      audio: true
    } as any);
    // Extract audio from displayStream
  }
}
```

## Linux PipeWire Implementation

The PipeWire virtual microphone implementation needs to be completed. Options:

1. Use `@vencord/venmic` approach (similar to Vesktop)
2. Use native PipeWire bindings (node-pipewire)
3. Use PulseAudio wrapper if PipeWire not available

See `src/main/audio/pipewire.ts` for the implementation interface.

