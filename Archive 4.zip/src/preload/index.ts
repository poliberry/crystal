/*
 * Preload Script
 * Exposes safe APIs to the renderer process
 */

import { contextBridge, ipcRenderer } from "electron";

// Screen Sharing API
const screenShare = {
  getSources: () =>
    ipcRenderer.invoke("crystal:screen-share:get-sources"),
  
  openPicker: (skipPicker?: boolean) =>
    ipcRenderer.invoke("crystal:screen-share:open-picker", { skipPicker }),
  
  pick: (choice: any) =>
    ipcRenderer.send("crystal:screen-share:pick", choice),
  
  cancel: () =>
    ipcRenderer.send("crystal:screen-share:cancel")
};

// Audio API
const audio = {
  getSources: () =>
    ipcRenderer.invoke("crystal:audio:get-sources"),
  
  startCapture: (options: { includeSources?: any; excludeSources?: any; sampleRate?: number; includeProcesses?: number[]; excludeProcesses?: number[] }) =>
    ipcRenderer.invoke("crystal:audio:start-capture", options),
  
  stopCapture: () =>
    ipcRenderer.invoke("crystal:audio:stop-capture"),
  
  // PCM capture via pw-cat (Linux only)
  checkPcmAvailable: () =>
    ipcRenderer.invoke("crystal:audio:check-pcm-available"),
  
  getPipeWireNodes: () =>
    ipcRenderer.invoke("crystal:audio:get-pipewire-nodes"),
  
  startPcmCapture: (options: { source?: string | number | null }) =>
    ipcRenderer.invoke("crystal:audio:start-pcm-capture", options),
  
  stopPcmCapture: () =>
    ipcRenderer.invoke("crystal:audio:stop-pcm-capture"),
  
  // Listen for PCM audio data (pw-cat)
  onPcmData: (callback: (data: { data: number[]; sampleRate: number; channels: number; bitsPerSample: number; frames: number }) => void) => {
    const handler = (_event: any, data: { data: number[]; sampleRate: number; channels: number; bitsPerSample: number; frames: number }) => {
      callback(data);
    };
    ipcRenderer.on("crystal:audio:pcm-data", handler);
    return () => {
      ipcRenderer.removeListener("crystal:audio:pcm-data", handler);
    };
  },
  
  // Listen for PCM audio errors
  onPcmError: (callback: (error: { error: string }) => void) => {
    const handler = (_event: any, error: { error: string }) => {
      callback(error);
    };
    ipcRenderer.on("crystal:audio:pcm-error", handler);
    return () => {
      ipcRenderer.removeListener("crystal:audio:pcm-error", handler);
    };
  },
  
  // Listen for audio data (macOS AudioTee)
  onAudioData: (callback: (data: { data: number[]; sampleRate: number; channels: number }) => void) => {
    const handler = (_event: any, data: { data: number[]; sampleRate: number; channels: number }) => {
      callback(data);
    };
    ipcRenderer.on("crystal:audio:data", handler);
    return () => {
      ipcRenderer.removeListener("crystal:audio:data", handler);
    };
  },
  
  // Listen for audio errors
  onAudioError: (callback: (error: { error: string }) => void) => {
    const handler = (_event: any, error: { error: string }) => {
      callback(error);
    };
    ipcRenderer.on("crystal:audio:error", handler);
    return () => {
      ipcRenderer.removeListener("crystal:audio:error", handler);
    };
  }
};

// Permissions API
const permissions = {
  requestCamera: () =>
    ipcRenderer.invoke("crystal:permissions:request-camera"),
  
  requestMicrophone: () =>
    ipcRenderer.invoke("crystal:permissions:request-microphone"),
  
  requestBoth: () =>
    ipcRenderer.invoke("crystal:permissions:request-both"),
  
  checkCamera: () =>
    ipcRenderer.invoke("crystal:permissions:check-camera"),
  
  checkMicrophone: () =>
    ipcRenderer.invoke("crystal:permissions:check-microphone"),
  
  checkScreenRecording: () =>
    ipcRenderer.invoke("crystal:permissions:check-screen-recording")
};

// Platform info
const platform = {
  get: () => process.platform,
  isWindows: () => process.platform === "win32",
  isLinux: () => process.platform === "linux",
  isMacOS: () => process.platform === "darwin"
};

// Expose APIs to renderer
contextBridge.exposeInMainWorld("CrystalNative", {
  screenShare,
  audio,
  permissions,
  platform
});

// Type definitions for TypeScript
declare global {
  interface Window {
    CrystalNative: {
      screenShare: {
        getSources: () => Promise<Array<{ id: string; name: string; thumbnail: string }>>;
        openPicker: (skipPicker?: boolean) => Promise<{
          id: string;
          contentHint?: "motion" | "detail";
          audio?: boolean;
          includeSources?: any;
          excludeSources?: any;
        } | null>;
        pick: (choice: any) => void;
        cancel: () => void;
      };
      audio: {
        getSources: () => Promise<{ ok: boolean; sources?: any[]; error?: string }>;
        startCapture: (options?: { includeSources?: any; excludeSources?: any; sampleRate?: number; includeProcesses?: number[]; excludeProcesses?: number[] }) => Promise<{ ok: boolean; error?: string; sampleRate?: number; message?: string }>;
        stopCapture: () => Promise<{ ok: boolean; error?: string }>;
        checkPcmAvailable: () => Promise<{ ok: boolean; available?: boolean; error?: string }>;
        getPipeWireNodes: () => Promise<{ ok: boolean; nodes?: Array<{ id: number; name: string; description?: string; mediaClass: string }>; error?: string }>;
        startPcmCapture: (options?: { source?: string | number | null }) => Promise<{ ok: boolean; error?: string }>;
        stopPcmCapture: () => Promise<{ ok: boolean; error?: string }>;
        onPcmData: (callback: (data: { data: number[]; sampleRate: number; channels: number; bitsPerSample: number; frames: number }) => void) => () => void;
        onPcmError: (callback: (error: { error: string }) => void) => () => void;
        onAudioData: (callback: (data: { data: number[]; sampleRate: number; channels: number }) => void) => () => void;
        onAudioError: (callback: (error: { error: string }) => void) => () => void;
      };
      permissions: {
        requestCamera: () => Promise<{ granted: boolean; platform?: string; status?: string; error?: string }>;
        requestMicrophone: () => Promise<{ granted: boolean; platform?: string; status?: string; error?: string }>;
        requestBoth: () => Promise<{
          camera: { granted: boolean };
          microphone: { granted: boolean };
          platform?: string;
          error?: string;
        }>;
        checkCamera: () => Promise<{ granted: boolean; status?: string; platform?: string; error?: string }>;
        checkMicrophone: () => Promise<{ granted: boolean; status?: string; platform?: string; error?: string }>;
        checkScreenRecording: () => Promise<{ granted: boolean; status?: string; platform?: string; message?: string; error?: string }>;
      };
      platform: {
        get: () => string;
        isWindows: () => boolean;
        isLinux: () => boolean;
        isMacOS: () => boolean;
      };
    };
  }
}

