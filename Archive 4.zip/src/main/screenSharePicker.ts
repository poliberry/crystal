/*
 * Screen Share Picker Window
 * Creates a window for selecting screen/window to share
 */

import { BrowserWindow, ipcMain } from "electron";
import { join } from "path";
import { ScreenSource, IPC_EVENTS } from "./screenShare";

const WINDOW_BACKGROUND_COLOR = "#1e1e1e";

let pickerWindow: BrowserWindow | null = null;

export function createScreenSharePicker(sources: ScreenSource[], skipPicker: boolean): BrowserWindow {
  if (pickerWindow) {
    pickerWindow.focus();
    return pickerWindow;
  }

  pickerWindow = new BrowserWindow({
    width: 800,
    height: 700,
    backgroundColor: WINDOW_BACKGROUND_COLOR,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
    show: false,
    frame: false,
    titleBarStyle: "hidden"
  });

  // Load picker HTML
  const pickerPath = join(__dirname, "../../static/html/screenSharePicker.html");
  pickerWindow.loadFile(pickerPath);

  // Send initial data
  pickerWindow.webContents.once("did-finish-load", () => {
    pickerWindow!.webContents.send("INIT_DATA", { sources, skipPicker });
    pickerWindow!.show();
  });

  // Note: IPC communication is handled via ipcRenderer.send() in the HTML file
  // The main process listens for these events in screenShare.ts

  pickerWindow.once("closed", () => {
    pickerWindow = null;
  });

  return pickerWindow;
}

