/*
 * Audio Handler
 * Handles system audio capture for all platforms
 */

import { ipcMain } from "electron";
import { registerLinuxAudio } from "./audio/linux";
import { registerWindowsAudio } from "./audio/windows";
import { registerMacOSAudio } from "./audio/macos";

const IPC_EVENTS = {
  AUDIO_GET_SOURCES: "crystal:audio:get-sources",
  AUDIO_START_CAPTURE: "crystal:audio:start-capture",
  AUDIO_STOP_CAPTURE: "crystal:audio:stop-capture",
  AUDIO_START_PCM_CAPTURE: "crystal:audio:start-pcm-capture",
  AUDIO_STOP_PCM_CAPTURE: "crystal:audio:stop-pcm-capture",
  AUDIO_CHECK_PCM_AVAILABLE: "crystal:audio:check-pcm-available",
  AUDIO_GET_PIPEWIRE_NODES: "crystal:audio:get-pipewire-nodes"
};

export function registerAudioHandler() {
  const platform = process.platform;

  if (platform === "linux") {
    registerLinuxAudio(IPC_EVENTS);
  } else if (platform === "win32") {
    registerWindowsAudio(IPC_EVENTS);
  } else if (platform === "darwin") {
    registerMacOSAudio(IPC_EVENTS);
  }
}

