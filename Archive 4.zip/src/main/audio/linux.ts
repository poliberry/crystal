/*
 * Linux Audio Handler
 * Uses PipeWire to create virtual microphone for system audio capture
 * Prefers @vencord/venmic native addon, falls back to pw-loopback
 * Also supports Electron's native PipeWire audio capture via getDisplayMedia
 * New: Direct PCM capture via pw-cat for RTCAudioSource
 */

import { ipcMain, session, desktopCapturer, BrowserWindow } from "electron";
import { startPwCatCapture, stopPwCatCapture, isPwCatAvailable, listPipeWireNodes } from "./pwcat";

// Try to use venmic first, fall back to pipewire
let useVenmic = false;
let venmicModule: any = null;
let pipewireModule: any = null;
let venmicInitialized = false;

async function initializeAudioModules() {
  if (venmicInitialized) return;
  
  // Try to use venmic first (native addon)
  try {
    venmicModule = require("./venmic");
    
    // Check if PipeWire is available before using venmic
    // hasPipeWire is exported from venmic.ts
    try {
      const hasPipeWire = venmicModule.hasPipeWire 
        ? await venmicModule.hasPipeWire()
        : false;
      
      if (hasPipeWire) {
        useVenmic = true;
        venmicInitialized = true;
        console.log("[Linux Audio] Using @vencord/venmic for virtual microphone (PipeWire detected)");
        return;
      } else {
        console.warn("[Linux Audio] venmic loaded but PipeWire not detected, falling back to pw-loopback");
      }
    } catch (pipewireCheckError) {
      // If PipeWire check fails, try to use venmic anyway
      // It will fail gracefully if PipeWire is not available
      console.warn("[Linux Audio] Could not check PipeWire availability, trying venmic anyway:", pipewireCheckError);
      useVenmic = true;
      venmicInitialized = true;
      console.log("[Linux Audio] Using @vencord/venmic for virtual microphone");
      return;
    }
  } catch (error) {
    console.warn("[Linux Audio] venmic not available, falling back to pw-loopback:", error);
  }
  
  // Fall back to pw-loopback implementation
  try {
    pipewireModule = require("./pipewire");
    useVenmic = false;
    venmicInitialized = true;
    console.log("[Linux Audio] Using pw-loopback for virtual microphone");
  } catch (pipewireError) {
    console.error("[Linux Audio] Neither venmic nor pipewire available:", pipewireError);
    venmicInitialized = true; // Mark as initialized even if failed to prevent retries
  }
}

// Initialize on module load
initializeAudioModules().catch(err => {
  console.error("[Linux Audio] Error initializing audio modules:", err);
});

interface IPCEvents {
  AUDIO_GET_SOURCES: string;
  AUDIO_START_CAPTURE: string;
  AUDIO_STOP_CAPTURE: string;
  AUDIO_START_PCM_CAPTURE?: string;
  AUDIO_STOP_PCM_CAPTURE?: string;
  AUDIO_CHECK_PCM_AVAILABLE?: string;
  AUDIO_GET_PIPEWIRE_NODES?: string;
}

export function registerLinuxAudio(events: IPCEvents) {
  // Register display media handler for Linux to enable native PipeWire audio capture
  // This allows getDisplayMedia with audio to work on Linux
  session.defaultSession.setDisplayMediaRequestHandler(
    async (request: any, callback: any) => {
      try {
        // Get available sources
        const sources = await desktopCapturer.getSources({
          types: ["window", "screen"],
          thumbnailSize: { width: 176, height: 99 }
        });

        // On Wayland with PipeWire, xdg-desktop-portal will handle window-specific audio
        // We just grant access - the portal picker will show audio toggle based on getDisplayMedia constraints
        if (sources.length > 0) {
          console.log("Granting access to screen source - portal will handle audio if requested");
          // Don't specify audio here - let the portal handle it based on getDisplayMedia constraints
          callback({ 
            video: sources[0],
            // Portal will automatically provide audio if getDisplayMedia requests it with displaySurface: 'window'
          });
        } else {
          console.warn("No screen sources available");
          callback({});
        }
      } catch (error) {
        console.error("Error in Linux display media handler:", error);
        callback({});
      }
    },
    { useSystemPicker: false } // Use Electron's picker, not system picker
  );

  // Get available audio sources (PipeWire nodes)
  ipcMain.handle(events.AUDIO_GET_SOURCES, async () => {
    try {
      // Ensure modules are initialized
      await initializeAudioModules();
      
      if (!venmicModule && !pipewireModule) {
        return { 
          ok: false, 
          error: "No audio capture implementation available. Please ensure PipeWire is installed." 
        };
      }
      
      const listAudioSources = useVenmic 
        ? venmicModule?.listAudioSources 
        : pipewireModule?.listAudioSources;
      
      if (!listAudioSources) {
        return { 
          ok: false, 
          error: "Audio source listing not available" 
        };
      }
      
      const sources = await listAudioSources();
      return {
        ok: true,
        sources: [
          { name: "None", value: "None" },
          { name: "Entire System", value: "Entire System" },
          ...sources.map((node: any) => ({
            name: node["application.name"] || node["node.name"] || "Unknown",
            value: node
          }))
        ]
      };
    } catch (error) {
      console.error("[Linux Audio] Error listing audio sources:", error);
      return { ok: false, error: String(error) };
    }
  });

  // Get available PipeWire nodes (for PCM capture)
  if (events.AUDIO_GET_PIPEWIRE_NODES) {
    ipcMain.handle(events.AUDIO_GET_PIPEWIRE_NODES, async () => {
      try {
        console.log("Listing PipeWire nodes...");
        const nodes = await listPipeWireNodes();
        console.log(`Found ${nodes.length} nodes`);
        
        const formattedNodes = nodes.map(node => ({
          id: node.id,
          name: node.applicationName || node.name || `Node ${node.id}`,
          description: node.description || node.name || `Application ${node.id}`,
          mediaClass: node.mediaClass
        }));
        
        console.log("Formatted nodes:", formattedNodes.slice(0, 3));
        
        return {
          ok: true,
          nodes: formattedNodes
        };
      } catch (error) {
        console.error("Error listing PipeWire nodes:", error);
        return { ok: false, error: String(error), nodes: [] };
      }
    });
  }

  // Start audio capture
  ipcMain.handle(
    events.AUDIO_START_CAPTURE,
    async (_event: any, { includeSources, excludeSources }: { includeSources?: any; excludeSources?: any }) => {
      try {
        // Ensure modules are initialized
        await initializeAudioModules();
        
        if (!venmicModule && !pipewireModule) {
          return { 
            ok: false, 
            error: "No audio capture implementation available. Please ensure PipeWire is installed." 
          };
        }
        
        const createVirtualMic = useVenmic
          ? venmicModule?.createVirtualMic
          : pipewireModule?.createVirtualMic;
        
        if (!createVirtualMic) {
          return { 
            ok: false, 
            error: "Virtual microphone creation not available" 
          };
        }
        
        if (includeSources === "Entire System") {
          await createVirtualMic({
            mode: "system",
            exclude: excludeSources || []
          });
        } else if (includeSources && includeSources !== "None") {
          const sources = Array.isArray(includeSources)
            ? includeSources
            : [includeSources];
          await createVirtualMic({
            mode: "selective",
            include: sources
          });
        } else {
          return { ok: false, error: "No audio sources specified" };
        }

        // Wait for virtual mic to be created
        // venmic is faster, so we can wait less
        const waitTime = useVenmic ? 500 : 1000;
        await new Promise((resolve) => setTimeout(resolve, waitTime));

        console.log("[Linux Audio] Virtual microphone started successfully");
        return { ok: true };
      } catch (error) {
        console.error("[Linux Audio] Error starting audio capture:", error);
        return { ok: false, error: String(error) };
      }
    }
  );

  // Stop audio capture
  ipcMain.handle(events.AUDIO_STOP_CAPTURE, async () => {
    try {
      if (!venmicModule && !pipewireModule) {
        return { ok: true }; // Already stopped or never started
      }
      
      const stopVirtualMic = useVenmic
        ? venmicModule?.stopVirtualMic
        : pipewireModule?.stopVirtualMic;
      
      if (stopVirtualMic) {
        await stopVirtualMic();
        console.log("[Linux Audio] Virtual microphone stopped");
      }
      
      return { ok: true };
    } catch (error) {
      console.error("[Linux Audio] Error stopping audio capture:", error);
      return { ok: false, error: String(error) };
    }
  });

  // Check if pw-cat PCM capture is available
  if (events.AUDIO_CHECK_PCM_AVAILABLE) {
    ipcMain.handle(events.AUDIO_CHECK_PCM_AVAILABLE, async () => {
      try {
        const available = isPwCatAvailable();
        return { ok: true, available };
      } catch (error) {
        console.error("Error checking pw-cat availability:", error);
        return { ok: false, available: false, error: String(error) };
      }
    });
  }

  // Start PCM audio capture via pw-cat
  if (events.AUDIO_START_PCM_CAPTURE) {
    ipcMain.handle(
      events.AUDIO_START_PCM_CAPTURE,
      async (event: any, { source }: { source?: string | number | null }) => {
        try {
          const window = BrowserWindow.fromWebContents(event.sender);
          if (!window) {
            return { ok: false, error: "Window not found" };
          }

          // If source is a node object, extract the ID
          let captureSource: string | number | null | undefined = source;
          if (source && typeof source === "object" && "id" in source) {
            captureSource = (source as any).id;
          }

          const result = await startPwCatCapture(window.id, captureSource);
          return result;
        } catch (error) {
          console.error("Error starting PCM capture:", error);
          return { ok: false, error: String(error) };
        }
      }
    );
  }

  // Stop PCM audio capture
  if (events.AUDIO_STOP_PCM_CAPTURE) {
    ipcMain.handle(events.AUDIO_STOP_PCM_CAPTURE, async () => {
      try {
        await stopPwCatCapture();
        return { ok: true };
      } catch (error) {
        console.error("Error stopping PCM capture:", error);
        return { ok: false, error: String(error) };
      }
    });
  }
}

