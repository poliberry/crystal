/*
 * Windows Audio Handler
 * Uses Electron's native loopback audio support
 */

import { ipcMain, session } from "electron";
import { desktopCapturer } from "electron";

interface IPCEvents {
  AUDIO_GET_SOURCES: string;
  AUDIO_START_CAPTURE: string;
  AUDIO_STOP_CAPTURE: string;
}

export function registerWindowsAudio(events: IPCEvents) {
  // Windows doesn't need audio source selection - it's handled by getDisplayMedia
  ipcMain.handle(events.AUDIO_GET_SOURCES, async () => {
    return {
      ok: true,
      sources: [{ name: "System Audio", value: "system" }]
    };
  });

  // Register display media handler for loopback audio
  // Note: This handler is called when getDisplayMedia is invoked in the renderer
  // We use the custom picker, so this is mainly for enabling loopback audio
  session.defaultSession.setDisplayMediaRequestHandler(async (request: any, callback: any) => {
    try {
      const sources = await desktopCapturer.getSources({
        types: ["window", "screen"],
        thumbnailSize: { width: 176, height: 99 }
      });

      // For Windows, we need to explicitly enable loopback audio
      // The callback should return { video: source, audio: "loopback" }
      // This enables Windows loopback audio capture via getDisplayMedia
      // Note: The actual source selection is handled by our custom picker,
      // so we just need to grant access with loopback audio enabled
      if (sources.length > 0) {
        // Try to find the source that matches the request (if available)
        // Otherwise, use the first available source
        const selectedSource = request.video || sources[0];
        
        console.log("Granting access to screen source with loopback audio on Windows");
        callback({ 
          video: selectedSource,
          audio: "loopback" // Enable Windows loopback audio - this is the key!
        });
      } else {
        console.warn("No screen sources available");
        callback({});
      }
    } catch (error) {
      console.error("Error in Windows display media handler:", error);
      callback({});
    }
  });

  // Start/stop are handled automatically by Electron's loopback
  ipcMain.handle(events.AUDIO_START_CAPTURE, async () => {
    return { ok: true, message: "Audio capture handled by getDisplayMedia" };
  });

  ipcMain.handle(events.AUDIO_STOP_CAPTURE, async () => {
    return { ok: true };
  });
}

