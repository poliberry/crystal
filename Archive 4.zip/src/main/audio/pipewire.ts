/*
 * PipeWire Virtual Microphone
 * Creates a virtual microphone device for system audio capture on Linux
 * 
 * Uses pw-loopback to create a virtual microphone source that captures
 * desktop audio and exposes it as a microphone input device.
 */

import { spawn, exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

export interface AudioNode {
  "application.name"?: string;
  "application.process.id"?: string;
  "node.name"?: string;
  "media.class"?: string;
  "media.name"?: string;
  "device.id"?: string;
}

export interface VirtualMicOptions {
  mode: "system" | "selective";
  include?: AudioNode[];
  exclude?: AudioNode[];
}

let virtualMicActive = false;
let virtualMicProcess: any = null;
let nullSinkModuleId: number | null = null;

const VIRTUAL_MIC_NAME = "crystal-screen-share";

/**
 * Check if PipeWire is available (required for pw-loopback)
 */
async function checkPipeWireAvailable(): Promise<boolean> {
  try {
    await execAsync("which pw-loopback");
    return true;
  } catch {
    return false;
  }
}

async function checkPulseAudioAvailable(): Promise<boolean> {
  try {
    await execAsync("which pactl");
    return true;
  } catch {
    return false;
  }
}

/**
 * List available audio sources using PipeWire or PulseAudio
 */
export async function listAudioSources(): Promise<AudioNode[]> {
  try {
    const isPW = await checkPipeWireAvailable();
    const isPA = await checkPulseAudioAvailable();
    
    // PipeWire can use pactl commands (PulseAudio compatibility layer)
    // So we can use pactl for both PipeWire and PulseAudio
    if (isPA) {
      try {
        // List sinks (audio outputs) that can be captured
        const { stdout } = await execAsync("pactl list sinks short");
        const lines = stdout.split('\n').filter(line => line.trim());
        return lines.map((line) => {
          const parts = line.split(/\s+/);
          const sinkName = parts[1] || parts[0];
          const description = parts.slice(2).join(' ') || sinkName;
          return {
            "node.name": sinkName,
            "application.name": description,
            "media.class": "Audio/Sink"
          };
        });
      } catch (error) {
        console.warn("Failed to list audio sources via pactl:", error);
      }
    }
    
    // Fallback: try pw-cli if available
    if (isPW) {
      try {
        const { stdout } = await execAsync(
          "pw-cli list-objects | grep -E 'Audio/Sink|Audio/Source/Virtual' || true"
        );
        
        const lines = stdout.split('\n').filter(line => line.trim());
        return lines.map((line, index) => ({
          "node.name": `node-${index}`,
          "application.name": line.trim(),
          "media.class": "Audio/Sink"
        }));
      } catch (error) {
        console.warn("Failed to list PipeWire sources:", error);
      }
    }
    
    return [];
  } catch (error) {
    console.error("Error listing audio sources:", error);
    return [];
  }
}

/**
 * Create a virtual microphone using pw-loopback
 * This creates a virtual microphone source that captures desktop audio
 */
export async function createVirtualMic(options: VirtualMicOptions): Promise<void> {
  if (virtualMicActive) {
    await stopVirtualMic();
  }

  try {
    const isPW = await checkPipeWireAvailable();
    const isPA = await checkPulseAudioAvailable();

    if (!isPW) {
      throw new Error("PipeWire (pw-loopback) is not available. Please install pipewire-utils.");
    }

    console.log("Creating virtual microphone using pw-loopback:", VIRTUAL_MIC_NAME);

    // Determine which sink to capture from
    let captureSinkName = "";
    let useNullSink = false;

    if (isPA) {
      if (options.mode === "system") {
        // For system mode, capture directly from the default sink's monitor
        // This doesn't disrupt the user's audio setup
        try {
          const { stdout: defaultSink } = await execAsync("pactl get-default-sink");
          captureSinkName = defaultSink.trim();
          console.log(`Using default sink for system capture: ${captureSinkName}`);
        } catch (error) {
          console.warn("Could not determine default sink, creating null sink:", error);
          // Fallback: create a null sink
          useNullSink = true;
        }
      } else if (options.mode === "selective" && options.include) {
        // For selective mode, create a null sink and route specific apps to it
        useNullSink = true;
      }

      // Create null sink if needed
      if (useNullSink) {
        try {
          const { stdout: existingSinks } = await execAsync(
            `pactl list short sinks | grep ${VIRTUAL_MIC_NAME} || true`
          );
          if (!existingSinks.trim()) {
            const { stdout } = await execAsync(
              `pactl load-module module-null-sink sink_name=${VIRTUAL_MIC_NAME} sink_properties=device.description="Crystal Screen Share Audio"`
            );
            
            const moduleId = parseInt(stdout.trim());
            if (!isNaN(moduleId)) {
              nullSinkModuleId = moduleId;
              console.log(`Created null sink with module ID: ${moduleId}`);
              captureSinkName = VIRTUAL_MIC_NAME;
              
              // For selective mode, route specific applications (TODO: implement)
              if (options.mode === "selective") {
                console.log("Selective mode: would route specific sources (not yet fully implemented)");
              }
            }
          } else {
            console.log("Null sink already exists");
            captureSinkName = VIRTUAL_MIC_NAME;
          }
        } catch (error) {
          console.warn("Failed to create null sink:", error);
          throw new Error("Failed to create null sink for audio capture");
        }
      }
    } else {
      throw new Error("PulseAudio/PipeWire compatibility layer required");
    }

    if (!captureSinkName) {
      throw new Error("Could not determine sink to capture from");
    }

    // Use pw-loopback to create the virtual microphone
    // This connects the sink's monitor to a virtual source
    try {
      console.log(`Starting pw-loopback to capture from: ${captureSinkName}.monitor`);

      // Start pw-loopback process
      // pw-loopback creates a loopback connection from a source to a virtual source
      // We capture from the sink's monitor (which is a source)
      // Note: The monitor source name format is typically "sink-name.monitor" in PulseAudio
      const monitorSourceName = `${captureSinkName}.monitor`;
      console.log(`Creating pw-loopback from monitor: ${monitorSourceName}`);
      
      // Use pw-loopback with flags to keep it running
      // --latency=1/48000 sets low latency
      // The process should stay alive as long as the connection is active
      virtualMicProcess = spawn("pw-loopback", [
        "--latency=1/48000",
        "--capture-props",
        `media.class=Audio/Source node.name=${monitorSourceName}`,
        "--playback-props",
        `media.class=Audio/Source node.name=${VIRTUAL_MIC_NAME} node.description="${VIRTUAL_MIC_NAME}"`
      ], {
        stdio: ['ignore', 'pipe', 'pipe'],
        env: { ...process.env },
        detached: false // Keep attached to parent process
      });
      
      // Unref would let the process run independently, but we want to keep it attached
      // Don't unref - we want to monitor it

      virtualMicProcess.on('error', (error: Error) => {
        console.error('pw-loopback process error:', error);
      });

      virtualMicProcess.stdout?.on('data', (data: Buffer) => {
        console.log('pw-loopback stdout:', data.toString());
      });

      virtualMicProcess.stderr?.on('data', (data: Buffer) => {
        console.log('pw-loopback stderr:', data.toString());
      });

      virtualMicProcess.on('exit', (code: number | null, signal: string | null) => {
        console.log(`pw-loopback exited with code ${code}, signal ${signal}`);
        if (code !== 0 && code !== null) {
          console.error('pw-loopback exited unexpectedly with error code:', code);
          virtualMicActive = false;
        }
        if (signal) {
          console.warn('pw-loopback was terminated by signal:', signal);
        }
        // If process exits while we think it's active, try to restart it
        if (virtualMicActive && code !== 0) {
          console.warn('pw-loopback exited while active, attempting to restart...');
          // Don't restart automatically - let the user know there's an issue
          virtualMicActive = false;
        }
      });
      
      // Keep the process alive by preventing it from being killed
      // Also monitor the process to ensure it stays running
      const keepAliveInterval = setInterval(() => {
        if (virtualMicProcess && !virtualMicProcess.killed && virtualMicProcess.exitCode === null) {
          // Process is still running
          try {
            process.kill(virtualMicProcess.pid, 0); // Check if process exists
          } catch (error) {
            console.error('pw-loopback process died unexpectedly');
            virtualMicActive = false;
            clearInterval(keepAliveInterval);
          }
        } else {
          console.warn('pw-loopback process is not running, clearing interval');
          clearInterval(keepAliveInterval);
        }
      }, 5000); // Check every 5 seconds
      
      // Store interval for cleanup
      (virtualMicProcess as any)._keepAliveInterval = keepAliveInterval;

      // Wait for the process to start and device to be registered
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Verify the process is still running
      if (virtualMicProcess.killed || virtualMicProcess.exitCode !== null) {
        const exitCode = virtualMicProcess.exitCode;
        const errorMsg = exitCode !== null 
          ? `pw-loopback process failed to start (exit code: ${exitCode})`
          : "pw-loopback process was killed before starting";
        console.error(errorMsg);
        throw new Error(errorMsg);
      }

      // Check if process is actually running
      try {
        process.kill(virtualMicProcess.pid, 0); // Signal 0 checks if process exists
        console.log("pw-loopback started successfully, PID:", virtualMicProcess.pid);
      } catch (error) {
        console.error("pw-loopback process is not running:", error);
        throw new Error("pw-loopback process is not running");
      }
    } catch (error) {
      console.error("Failed to start pw-loopback:", error);
      // Clean up null sink if we created it
      if (nullSinkModuleId !== null && isPA) {
        try {
          await execAsync(`pactl unload-module ${nullSinkModuleId}`);
        } catch (cleanupError) {
          console.warn("Failed to cleanup null sink:", cleanupError);
        }
        nullSinkModuleId = null;
      }
      throw error;
    }

    virtualMicActive = true;
    
    // Wait for the device to be registered
    await new Promise(resolve => setTimeout(resolve, 500));
    
    console.log("Virtual microphone created successfully");
  } catch (error) {
    console.error("Error creating virtual microphone:", error);
    virtualMicActive = false;
    nullSinkModuleId = null;
    if (virtualMicProcess) {
      virtualMicProcess.kill();
      virtualMicProcess = null;
    }
    throw error;
  }
}

/**
 * Stop the virtual microphone and clean up resources
 */
export async function stopVirtualMic(): Promise<void> {
  if (!virtualMicActive && !virtualMicProcess && nullSinkModuleId === null) {
    return;
  }

  try {
    // Stop pw-loopback process
    if (virtualMicProcess) {
      // Clear keepalive interval if it exists
      if ((virtualMicProcess as any)._keepAliveInterval) {
        clearInterval((virtualMicProcess as any)._keepAliveInterval);
      }
      
      try {
        virtualMicProcess.kill('SIGTERM');
        // Wait a bit for graceful shutdown
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Force kill if still running
        if (!virtualMicProcess.killed && virtualMicProcess.exitCode === null) {
          virtualMicProcess.kill('SIGKILL');
        }
        console.log("Stopped pw-loopback process");
      } catch (error) {
        console.warn("Error stopping pw-loopback process:", error);
      }
      virtualMicProcess = null;
    }

    // Unload null sink module if we created it
    if (nullSinkModuleId !== null) {
      try {
        await execAsync(`pactl unload-module ${nullSinkModuleId}`);
        console.log(`Unloaded null sink module: ${nullSinkModuleId}`);
      } catch (error) {
        console.warn("Failed to unload null sink module:", error);
        // Try to find and unload by name
        try {
          await execAsync(`pactl unload-module $(pactl list short modules | grep "module-null-sink.*${VIRTUAL_MIC_NAME}" | awk '{print $1}')`);
        } catch (nameError) {
          console.warn("Failed to unload null sink by name:", nameError);
        }
      }
      nullSinkModuleId = null;
    }

    virtualMicActive = false;
    console.log("Virtual microphone stopped");
  } catch (error) {
    console.error("Error stopping virtual microphone:", error);
    // Reset state even if cleanup fails
    virtualMicActive = false;
    nullSinkModuleId = null;
    if (virtualMicProcess) {
      virtualMicProcess.kill('SIGKILL');
      virtualMicProcess = null;
    }
  }
}

/**
 * Check if PipeWire is available on the system
 */
export async function isPipeWireAvailable(): Promise<boolean> {
  try {
    await execAsync("which pw-cli");
    return true;
  } catch {
    return false;
  }
}
