/*
 * PipeWire Audio Capture using pw-record
 * Captures system audio and app audio via pw-record and streams PCM data via IPC
 * Uses pw-record for cleaner capture without routing
 */

import { spawn, ChildProcess, exec, execSync } from "child_process";
import { promisify } from "util";
import { ipcMain, BrowserWindow } from "electron";

const execAsync = promisify(exec);

let pwRecordProcess: ChildProcess | null = null;
let audioDataListener: ((data: Buffer) => void) | null = null;
let targetWindow: BrowserWindow | null = null;
let nullSinkModuleId: number | null = null;
let nullSinkName: string | null = null;
let loopbackModuleId: number | null = null;
let movedSinkInputId: number | null = null;
let originalSinkName: string | null = null;

const SAMPLE_RATE = 48000;
const CHANNELS = 2;
const BITS_PER_SAMPLE = 16;
const BYTES_PER_SAMPLE = BITS_PER_SAMPLE / 8;
const BYTES_PER_FRAME = CHANNELS * BYTES_PER_SAMPLE;

export interface PipeWireNode {
  id: number;
  name: string;
  applicationName?: string;
  mediaClass: string;
  description?: string;
}

const APP_NAME = "crystal";
const SINK_NAME = "ScreenShareMix";
// Keep track of already linked nodes
const linkedNodes = new Set<number>();

/**
 * Get the default sink's monitor source name
 */
async function getDefaultMonitor(): Promise<string | null> {
  try {
    // Get default sink name
    const { stdout: sinkStdout } = await execAsync("pactl get-default-sink");
    const sinkName = sinkStdout.trim();

    if (!sinkName) {
      return null;
    }

    // Monitor source is the sink name with .monitor suffix
    return `${sinkName}.monitor`;
  } catch (error) {
    console.error("Error getting default monitor:", error);
    return null;
  }
}

/**
 * Find the sink-input ID for a given PipeWire node ID
 * Uses pw-cli to get the actual node and then matches it to sink-inputs
 */
async function findSinkInputForNode(nodeId: number): Promise<number | null> {
  try {
    // First, get the node information from pw-cli to get application details
    let nodeInfo: { applicationName?: string; processId?: string; nodeName?: string } = {};

    try {
      const { stdout: nodeDetails } = await execAsync(`pw-cli info ${nodeId} || true`);

      // Parse node details
      const lines = nodeDetails.split('\n');
      for (const line of lines) {
        if (line.includes('application.name = ')) {
          const match = line.match(/application\.name = "([^"]+)"/);
          if (match) nodeInfo.applicationName = match[1];
        } else if (line.includes('application.process.id = ')) {
          const match = line.match(/application\.process\.id = "?(\d+)"?/);
          if (match) nodeInfo.processId = match[1];
        } else if (line.includes('node.name = ')) {
          const match = line.match(/node\.name = "([^"]+)"/);
          if (match) nodeInfo.nodeName = match[1];
        }
      }
    } catch (e) {
      console.warn("Could not get node info from pw-cli, trying alternative method");
    }

    // List all sink-inputs and try to match
    const { stdout: sinkInputsList } = await execAsync("pactl list sink-inputs short");
    const lines = sinkInputsList.split('\n').filter(line => line.trim());

    // For each sink-input, get detailed info and try to match
    for (const line of lines) {
      const parts = line.split(/\s+/);
      const sinkInputId = parseInt(parts[0], 10);
      if (isNaN(sinkInputId)) continue;

      try {
        // Get detailed info for this sink-input
        const { stdout: inputInfo } = await execAsync(`pactl list sink-inputs | grep -A 30 "Sink Input #${sinkInputId}"`);

        // Try to match by process ID first (most reliable)
        if (nodeInfo.processId && inputInfo.includes(`application.process.id = "${nodeInfo.processId}"`)) {
          console.log(`Matched node ${nodeId} to sink-input ${sinkInputId} by process ID`);
          return sinkInputId;
        }

        // Try to match by application name
        if (nodeInfo.applicationName && inputInfo.includes(`application.name = "${nodeInfo.applicationName}"`)) {
          console.log(`Matched node ${nodeId} to sink-input ${sinkInputId} by application name`);
          return sinkInputId;
        }

        // Try to match by node name (if available)
        if (nodeInfo.nodeName && inputInfo.includes(nodeInfo.nodeName)) {
          console.log(`Matched node ${nodeId} to sink-input ${sinkInputId} by node name`);
          return sinkInputId;
        }
      } catch (e) {
        // Continue to next sink-input
        continue;
      }
    }

    // Fallback: if we have node info but couldn't match, try wpctl
    if (nodeInfo.applicationName || nodeInfo.processId) {
      try {
        const { stdout: wpctlStatus } = await execAsync("wpctl status");
        const lines = wpctlStatus.split('\n');

        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          // Look for sink-input lines that might match our app
          if (line.includes('Sink Input') && (nodeInfo.applicationName ? line.includes(nodeInfo.applicationName) : true)) {
            const match = line.match(/Sink Input #(\d+)/);
            if (match) {
              const inputId = parseInt(match[1], 10);
              console.log(`Matched node ${nodeId} to sink-input ${inputId} via wpctl`);
              return inputId;
            }
          }
        }
      } catch (e) {
        console.warn("wpctl not available for sink-input matching");
      }
    }

    console.warn(`Could not find sink-input for node ${nodeId}`);
    return null;
  } catch (error) {
    console.error("Error finding sink-input for node:", error);
    return null;
  }
}

/**
 * Create a null sink for app-specific audio capture
 * Also creates a loopback to the default sink so the user can still hear the audio
 */
async function createNullSinkForApp(sinkName: string): Promise<{ moduleId: number; sinkName: string; loopbackModuleId: number } | null> {
  try {
    // Get default sink for loopback
    let defaultSink: string;
    try {
      const { stdout } = await execAsync("pactl get-default-sink");
      defaultSink = stdout.trim();
    } catch (e) {
      console.error("Could not get default sink for loopback:", e);
      defaultSink = "@DEFAULT_SINK@";
    }

    // Check if sink already exists
    const { stdout: existingSinks } = await execAsync(
      `pactl list short sinks | grep ${sinkName} || true`
    );

    let moduleId: number | null = null;

    if (existingSinks.trim()) {
      // Sink exists, find its module ID
      const { stdout: modules } = await execAsync("pactl list short modules");
      const lines = modules.split('\n');
      for (const line of lines) {
        if (line.includes(`module-null-sink`) && line.includes(sinkName)) {
          const parts = line.split(/\s+/);
          const foundModuleId = parseInt(parts[0], 10);
          if (!isNaN(foundModuleId)) {
            moduleId = foundModuleId;
            console.log(`Using existing null sink: ${sinkName} (module ${moduleId})`);
            // Check if loopback already exists
            const { stdout: loopbackModules } = await execAsync("pactl list short modules");
            const loopbackLines = loopbackModules.split('\n');
            for (const loopbackLine of loopbackLines) {
              if (loopbackLine.includes(`module-loopback`) && loopbackLine.includes(sinkName)) {
                const loopbackParts = loopbackLine.split(/\s+/);
                const existingLoopbackId = parseInt(loopbackParts[0], 10);
                if (!isNaN(existingLoopbackId)) {
                  return { moduleId, sinkName, loopbackModuleId: existingLoopbackId };
                }
              }
            }
            // Need to create loopback
            break;
          }
        }
      }
    }

    // Create new null sink if it doesn't exist
    if (moduleId === null) {
      const { stdout } = await execAsync(
        `pactl load-module module-null-sink sink_name=${sinkName} sink_properties=device.description="Crystal App Audio Capture"`
      );

      moduleId = parseInt(stdout.trim(), 10);
      if (isNaN(moduleId)) {
        throw new Error("Failed to create null sink - invalid module ID");
      }

      console.log(`Created null sink: ${sinkName} (module ${moduleId})`);
    }

    // Create loopback from null sink monitor to default sink
    // This allows the user to still hear the audio while we capture it
    const { stdout: loopbackStdout } = await execAsync(
      `pactl load-module module-loopback source=${sinkName}.monitor sink=${defaultSink} latency_msec=1`
    );

    const loopbackModuleId = parseInt(loopbackStdout.trim(), 10);
    if (isNaN(loopbackModuleId)) {
      console.warn("Failed to create loopback, user won't hear audio but capture will still work");
      return { moduleId, sinkName, loopbackModuleId: -1 };
    }

    console.log(`Created loopback from ${sinkName}.monitor to ${defaultSink} (module ${loopbackModuleId})`);
    return { moduleId, sinkName, loopbackModuleId };
  } catch (error) {
    console.error("Error creating null sink:", error);
    return null;
  }
}

/**
 * Move a sink-input to a different sink
 */
async function moveSinkInput(sinkInputId: number, targetSinkName: string): Promise<boolean> {
  try {
    await execAsync(`pactl move-sink-input ${sinkInputId} ${targetSinkName}`);
    console.log(`Moved sink-input ${sinkInputId} to ${targetSinkName}`);
    return true;
  } catch (error) {
    console.error(`Error moving sink-input ${sinkInputId}:`, error);
    return false;
  }
}

/**
 * Get the sink name that a sink-input is currently connected to
 */
async function getSinkInputSink(sinkInputId: number): Promise<string | null> {
  try {
    const { stdout } = await execAsync(`pactl list sink-inputs | grep -A 5 "Sink Input #${sinkInputId}" | grep "Sink:"`);
    const match = stdout.match(/Sink: (.+)/);
    if (match) {
      return match[1].trim();
    }
    return null;
  } catch (error) {
    console.error(`Error getting sink for sink-input ${sinkInputId}:`, error);
    return null;
  }
}

/**
 * List available PipeWire audio nodes (applications)
 * Uses pw-cli to find applications with audio output streams
 */
export async function listPipeWireNodes(): Promise<PipeWireNode[]> {
  try {
    let stdout: string;
    let usePwCli = true;

    // Try pw-cli first
    try {
      const result = await execAsync('pw-cli ls Node || true', { timeout: 5000 });
      stdout = result.stdout;
      if (!stdout || stdout.trim().length === 0) {
        throw new Error("pw-cli returned empty output");
      }
      console.log("pw-cli output length:", stdout.length);
    } catch (error) {
      console.warn("pw-cli failed, trying alternative method:", error);
      usePwCli = false;
      // Fallback: try to get sink inputs via pactl (shows applications)
      try {
        const result = await execAsync('pactl list sink-inputs || true', { timeout: 5000 });
        stdout = result.stdout;
        console.log("Using pactl fallback, output length:", stdout.length);
      } catch (pactlError) {
        console.error("Both pw-cli and pactl failed:", pactlError);
        return [];
      }
    }

    const nodes: PipeWireNode[] = [];

    if (usePwCli) {
      // Parse pw-cli output
      const lines = stdout.split('\n');
      let currentNode: Partial<PipeWireNode> = {};
      let inNode = false;
      let foundAudioNode = false;

      for (const line of lines) {
        // Node ID line: "id <number>, type PipeWire:Interface:Node"
        if (line.includes('id ') && line.includes('type PipeWire:Interface:Node')) {
          const idMatch = line.match(/id (\d+)/);
          if (idMatch) {
            // Save previous node if it was an audio output node
            if (inNode && currentNode.id !== undefined && foundAudioNode) {
              if (currentNode.name) {
                nodes.push(currentNode as PipeWireNode);
              }
            }
            currentNode = { id: parseInt(idMatch[1], 10) };
            inNode = true;
            foundAudioNode = false;
          }
        } else if (inNode) {
          // Parse node properties
          if (line.includes('node.name = ')) {
            const match = line.match(/node\.name = "([^"]+)"/);
            if (match) currentNode.name = match[1];
          } else if (line.includes('application.name = ')) {
            const match = line.match(/application\.name = "([^"]+)"/);
            if (match) currentNode.applicationName = match[1];
          } else if (line.includes('media.class = ')) {
            const match = line.match(/media\.class = "([^"]+)"/);
            if (match) {
              currentNode.mediaClass = match[1];
              // Check if this is an audio output stream
              if (match[1] === 'Stream/Output/Audio') {
                foundAudioNode = true;
              }
            }
          } else if (line.includes('node.description = ')) {
            const match = line.match(/node\.description = "([^"]+)"/);
            if (match) currentNode.description = match[1];
          }
        }
      }

      // Add last node if it was an audio output node
      if (inNode && currentNode.id !== undefined && foundAudioNode && currentNode.name) {
        nodes.push(currentNode as PipeWireNode);
      }
    } else {
      // Parse pactl sink-inputs output (fallback)
      // Format: Sink Input #<id> ... application.name = "<name>"
      const lines = stdout.split('\n');
      let currentInput: Partial<PipeWireNode> = {};

      for (const line of lines) {
        // Sink Input line: "Sink Input #<id>"
        const inputMatch = line.match(/Sink Input #(\d+)/);
        if (inputMatch) {
          if (currentInput.id !== undefined && currentInput.name) {
            nodes.push({
              id: currentInput.id,
              name: currentInput.name,
              applicationName: currentInput.name,
              mediaClass: 'Stream/Output/Audio',
              description: currentInput.description || currentInput.name
            } as PipeWireNode);
          }
          currentInput = { id: parseInt(inputMatch[1], 10) };
        } else if (currentInput.id !== undefined) {
          // Parse properties
          const appMatch = line.match(/application\.name = "([^"]+)"/);
          if (appMatch) {
            currentInput.name = appMatch[1];
            currentInput.applicationName = appMatch[1];
          }
          const descMatch = line.match(/application\.process\.binary = "([^"]+)"/);
          if (descMatch) {
            currentInput.description = descMatch[1];
          }
        }
      }

      // Add last input
      if (currentInput.id !== undefined && currentInput.name) {
        nodes.push({
          id: currentInput.id,
          name: currentInput.name,
          applicationName: currentInput.name,
          mediaClass: 'Stream/Output/Audio',
          description: currentInput.description || currentInput.name
        } as PipeWireNode);
      }
    }

    console.log(`Found ${nodes.length} PipeWire audio output nodes`);
    if (nodes.length > 0) {
      console.log("Sample nodes:", nodes.slice(0, 3).map(n => ({ id: n.id, name: n.applicationName || n.name })));
    } else {
      console.warn("No audio output nodes found. Make sure some applications are playing audio.");
    }

    return nodes;
  } catch (error) {
    console.error("Error listing PipeWire nodes:", error);
    return [];
  }
}

/**
 * Start capturing audio using pw-cat
 * @param windowId - BrowserWindow ID to send audio data to
 * @param source - Audio source to capture:
 *   - null or "Entire System": default sink monitor (system audio)
 *   - number: PipeWire node ID (application-specific)
 *   - string: monitor source name or node name
 */
export function startPwCatCapture(windowId: number, source?: string | number | null): Promise<{ ok: boolean; error?: string }> {
  return new Promise(async (resolve) => {
    try {
      // Stop any existing capture
      if (pwRecordProcess) {
        stopPwCatCapture();
      }

      // Find the target window
      const window = BrowserWindow.fromId(windowId);
      if (!window) {
        resolve({ ok: false, error: "Window not found" });
        return;
      }
      targetWindow = window;

      // Build pw-record command
      // pw-record -f raw outputs raw PCM data to stdout
      const args = [
        "-a",
        "-" // Output to stdout
      ];

      // Determine capture mode
      if (source === null || source === "Entire System" || source === "None" || source === undefined) {
        function createVirtualSink() {
          try {
            execSync(`pw-cli create-object filter-chain '{
              "node.name": "${SINK_NAME}",
              "media.class": "Audio/Sink",
              "filter.graph": {
                "nodes": [
                  {
                    "type": "mix",
                    "name": "mix",
                    "inputs": 32
                  },
                  {
                    "type": "ladspa",
                    "name": "exclude_crystal",
                    "plugin": "lsp-plugins-limiter-stereo",
                    "label": "limiter_stereo",
                    "control": { "enable": false }
                  }
                ],
                "links": [
                  { "output": "mix:Out", "input": "exclude_crystal:In" }
                ]
              },
              "capture.props": {
                "media.class": "Audio/Sink",
                "node.name": "${SINK_NAME}.capture"
              }
            }'`);
          } catch (e) {
            console.log("Sink may already exist:", e instanceof Error ? e.message : String(e));
          }
        }

        function updateLinkedNodes() {
          const output = execSync("pw-cli list-objects Node").toString();
          const matches = [...output.matchAll(/id\s+(\d+)[\s\S]*?application.name = "([^"]+)"/g)];

          for (const [, idStr, name] of matches) {
            const id = parseInt(idStr, 10);
            if (!name.includes(APP_NAME) && !name.toLowerCase().includes("mic") && !linkedNodes.has(id)) {
              try {
                execSync(`pw-link ${id}.output ${SINK_NAME}:input`);
                linkedNodes.add(id);
              } catch (e) {
                console.warn(`Failed to link ${name} (id ${id}): ${e instanceof Error ? e.message : String(e)}`);
              }
            }
          }
        }


        createVirtualSink();
        updateLinkedNodes();
        // System audio: use pw-record with sink capture property
        args.push("-P", `target.object=${SINK_NAME}.capture`);
        console.log("Capturing system audio using pw-record with sink capture");
      } else if (typeof source === "number") {
        // Application-specific: get application name from node ID
        const nodeId = source;

        // Get application name from the node
        let applicationName: string | null = null;
        try {
          const { stdout: nodeInfo } = await execAsync(`pw-cli info ${nodeId} || true`);
          const lines = nodeInfo.split('\n');
          for (const line of lines) {
            if (line.includes('application.name = ')) {
              const match = line.match(/application\.name = "([^"]+)"/);
              if (match) {
                applicationName = match[1];
                break;
              }
            }
          }
        } catch (e) {
          console.warn("Could not get application name from node:", e);
        }

        if (!applicationName) {
          resolve({ ok: false, error: `Could not determine application name for node ${nodeId}` });
          return;
        }

        // Use --target with application name
        args.push("--target", applicationName);
        console.log(`Capturing app audio for "${applicationName}" (node ${nodeId})`);
      } else if (typeof source === "string") {
        // Check if it's a numeric string (node ID)
        const numericSource = parseInt(source, 10);
        if (!isNaN(numericSource)) {
          // Treat as node ID - recurse
          return startPwCatCapture(windowId, numericSource);
        } else {
          // Use as application name directly
          args.push("--target", source);
          console.log(`Capturing app audio for "${source}"`);
        }
      }

      console.log("Starting pw-record with args:", args);

      // Spawn pw-record process
      pwRecordProcess = spawn("pw-record", args, {
        stdio: ["ignore", "pipe", "pipe"], // stdin: ignore, stdout: pipe, stderr: pipe
        detached: false
      });

      if (!pwRecordProcess) {
        resolve({ ok: false, error: "Failed to spawn pw-record process" });
        return;
      }

      // Handle stdout (audio data)
      pwRecordProcess.stdout?.on("data", (chunk: Buffer) => {
        if (targetWindow && !targetWindow.isDestroyed()) {
          // Send audio data to renderer via IPC
          targetWindow.webContents.send("crystal:audio:pcm-data", {
            data: Array.from(chunk), // Convert Buffer to array for IPC
            sampleRate: SAMPLE_RATE,
            channels: CHANNELS,
            bitsPerSample: BITS_PER_SAMPLE,
            frames: chunk.length / BYTES_PER_FRAME
          });
        }
      });

      // Handle stderr (errors/logs)
      pwRecordProcess.stderr?.on("data", (data: Buffer) => {
        const message = data.toString();
        console.log("pw-record stderr:", message);
        if (targetWindow && !targetWindow.isDestroyed()) {
          targetWindow.webContents.send("crystal:audio:pcm-error", {
            error: message
          });
        }
      });

      // Handle process exit
      pwRecordProcess.on("exit", (code: number | null, signal: string | null) => {
        console.log(`pw-record process exited with code ${code}, signal ${signal}`);
        if (code !== 0 && code !== null) {
          if (targetWindow && !targetWindow.isDestroyed()) {
            targetWindow.webContents.send("crystal:audio:pcm-error", {
              error: `pw-record exited with code ${code}`
            });
          }
        }
        pwRecordProcess = null;
        targetWindow = null;
      });

      // Handle process errors
      pwRecordProcess.on("error", (error: Error) => {
        console.error("pw-record process error:", error);
        if (targetWindow && !targetWindow.isDestroyed()) {
          targetWindow.webContents.send("crystal:audio:pcm-error", {
            error: error.message
          });
        }
        pwRecordProcess = null;
        targetWindow = null;
        resolve({ ok: false, error: error.message });
      });

      // Wait a bit to see if process starts successfully
      setTimeout(() => {
        if (pwRecordProcess && !pwRecordProcess.killed) {
          console.log("pw-record process started successfully");
          resolve({ ok: true });
        } else {
          resolve({ ok: false, error: "pw-record process failed to start" });
        }
      }, 500);

    } catch (error: any) {
      console.error("Error starting pw-record capture:", error);
      resolve({ ok: false, error: error.message || String(error) });
    }
  });
}

/**
 * Stop capturing audio and clean up resources
 * IMPORTANT: Restore sink-input BEFORE unloading modules to avoid audio loss
 */
export async function stopPwCatCapture(): Promise<void> {
  if (pwRecordProcess) {
    console.log("Stopping pw-record process");
    pwRecordProcess.kill();
    execSync(`pw-cli destroy ${SINK_NAME}`);
    linkedNodes.clear();
    pwRecordProcess = null;
  }

  // With pw-record, we don't need to clean up null sinks or loopbacks
  // since we're not routing audio anymore - pw-record captures directly
  // Just reset state variables
  movedSinkInputId = null;
  originalSinkName = null;
  loopbackModuleId = null;
  nullSinkModuleId = null;
  nullSinkName = null;

  console.log("PCM capture cleanup completed");

  targetWindow = null;
  audioDataListener = null;
}

/**
 * Check if pw-cat is available
 */
export function isPwCatAvailable(): boolean {
  try {
    // Try to spawn pw-cat with --help to check if it exists
    const testProcess = spawn("pw-cat", ["--help"], {
      stdio: "ignore",
      timeout: 2000
    });
    return true; // If spawn succeeds, pw-cat exists
  } catch {
    return false;
  }
}

/**
 * Check if pw-cli is available (for listing nodes)
 */
export async function isPwCliAvailable(): Promise<boolean> {
  try {
    await execAsync("pw-cli --version");
    return true;
  } catch {
    return false;
  }
}



