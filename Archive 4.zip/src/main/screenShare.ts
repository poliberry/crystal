/*
 * Screen Sharing Handler
 * Handles screen/window selection and video capture
 */

import { desktopCapturer, ipcMain, BrowserWindow, systemPreferences } from "electron";
import { join } from "path";
import { createScreenSharePicker } from "./screenSharePicker";

export interface ScreenSource {
  id: string;
  name: string;
  thumbnail: string;
}

export interface ScreenShareChoice {
  id: string;
  contentHint?: "motion" | "detail";
  audio?: boolean;
  includeSources?: any; // For Linux venmic
  excludeSources?: any; // For Linux venmic
}

export const IPC_EVENTS = {
  SCREEN_SHARE_GET_SOURCES: "crystal:screen-share:get-sources",
  SCREEN_SHARE_OPEN_PICKER: "crystal:screen-share:open-picker",
  SCREEN_SHARE_PICK: "crystal:screen-share:pick",
  SCREEN_SHARE_CANCEL: "crystal:screen-share:cancel"
};

export function registerScreenShareHandler() {
  // Get available screen/window sources
  ipcMain.handle(IPC_EVENTS.SCREEN_SHARE_GET_SOURCES, async () => {
    try {
      const sources = await desktopCapturer.getSources({
        types: ["window", "screen"],
        thumbnailSize: {
          width: 1920,
          height: 1080
        },
        fetchWindowIcons: true
      });

      return sources.map(({ id, name, thumbnail }) => ({
        id,
        name,
        thumbnail: thumbnail.toDataURL()
      }));
    } catch (error) {
      console.error("Error getting screen sources:", error);
      return [];
    }
  });

  // Open screen share picker window
  ipcMain.handle(
    IPC_EVENTS.SCREEN_SHARE_OPEN_PICKER,
    async (event, { skipPicker = false }): Promise<ScreenShareChoice | null> => {
      return new Promise(async (resolve, reject) => {
        try {
          // Check screen recording permission on macOS before getting sources
          if (process.platform === "darwin") {
            try {
              const screenStatus = systemPreferences.getMediaAccessStatus("screen");
              if (screenStatus !== "granted") {
                const error = new Error("Screen recording permission is required. Please enable it in System Preferences > Security & Privacy > Screen Recording.");
                (error as any).permissionDenied = true;
                (error as any).permissionStatus = screenStatus;
                reject(error);
                return;
              }
            } catch (permError) {
              console.error("Error checking screen recording permission:", permError);
              const error = new Error("Failed to check screen recording permission. Please ensure it's enabled in System Preferences > Security & Privacy > Screen Recording.");
              (error as any).permissionDenied = true;
              reject(error);
              return;
            }
          }

          // Get sources with error handling
          let sources;
          try {
            sources = await desktopCapturer.getSources({
              types: ["window", "screen"],
              thumbnailSize: {
                width: 176,
                height: 99
              }
            });
          } catch (sourcesError: any) {
            console.error("Error getting screen sources:", sourcesError);
            // If we get an error getting sources, it's likely a permission issue
            const error = new Error("Failed to get screen sources. Please ensure screen recording permission is enabled in System Preferences > Security & Privacy > Screen Recording.");
            (error as any).permissionDenied = true;
            (error as any).originalError = sourcesError.message;
            reject(error);
            return;
          }

          if (!sources || sources.length === 0) {
            const error = new Error("No screen sources available. Please ensure screen recording permission is enabled.");
            (error as any).permissionDenied = true;
            reject(error);
            return;
          }

          const data = sources.map(({ id, name, thumbnail }) => {
            let thumbnailData = "";
            try {
              thumbnailData = thumbnail ? thumbnail.toDataURL() : "";
            } catch (thumbError) {
              console.warn("Error converting thumbnail to data URL:", thumbError);
              thumbnailData = "";
            }
            return {
              id,
              name: name || "Unknown",
              thumbnail: thumbnailData
            };
          });

          // Create picker window with error handling
          let pickerWindow: BrowserWindow;
          try {
            pickerWindow = createScreenSharePicker(data, skipPicker);
          } catch (pickerError) {
            console.error("Error creating picker window:", pickerError);
            reject(new Error("Failed to create screen share picker window."));
            return;
          }

          // Track if we've already resolved/rejected to prevent double handling
          let isResolved = false;

          // Handle picker response via IPC
          const pickHandler = (_event: any, choice: ScreenShareChoice) => {
            if (isResolved) return;
            isResolved = true;
            
            // Close the picker window
            if (pickerWindow && !pickerWindow.isDestroyed()) {
              pickerWindow.close();
            }
            resolve(choice);
            cleanup();
          };

          const cancelHandler = () => {
            if (isResolved) return;
            isResolved = true;
            
            // Close the picker window on cancel
            if (pickerWindow && !pickerWindow.isDestroyed()) {
              pickerWindow.close();
            }
            reject(new Error("Aborted"));
            cleanup();
          };

          const cleanup = () => {
            ipcMain.removeListener(IPC_EVENTS.SCREEN_SHARE_PICK, pickHandler);
            ipcMain.removeListener(IPC_EVENTS.SCREEN_SHARE_CANCEL, cancelHandler);
          };

          ipcMain.on(IPC_EVENTS.SCREEN_SHARE_PICK, pickHandler);
          ipcMain.on(IPC_EVENTS.SCREEN_SHARE_CANCEL, cancelHandler);

          // Clean up on window close (only if user closes manually)
          // Only reject if we haven't already resolved/rejected
          pickerWindow.once("closed", () => {
            if (!isResolved) {
              isResolved = true;
              reject(new Error("Aborted"));
            }
            cleanup();
          });
        } catch (error: any) {
          console.error("Unexpected error in screen share picker:", error);
          // Ensure we don't crash - always reject with a proper error
          const safeError = error instanceof Error 
            ? error 
            : new Error(String(error || "Unknown error occurred"));
          reject(safeError);
        }
      });
    }
  );

  // Handle picker choice (called from picker window)
  ipcMain.on(IPC_EVENTS.SCREEN_SHARE_PICK, (event, choice: ScreenShareChoice) => {
    // This is handled in the promise above
  });

  // Handle picker cancel (called from picker window)
  ipcMain.on(IPC_EVENTS.SCREEN_SHARE_CANCEL, () => {
    // This is handled in the promise above
  });
}

