/*
 * Crystal Electron Wrapper
 * Native screen sharing with system audio support
 */

import { app, BrowserWindow } from "electron";
import { join } from "path";
import { registerScreenShareHandler } from "./screenShare";
import { registerAudioHandler } from "./audio";
import { registerPermissionsHandler } from "./permissions";

const isDev = process.env.NODE_ENV === "development" || !app.isPackaged;

export let mainWindow: BrowserWindow | null = null;

// Enable PipeWire capture for native xdg-desktop-portal support (Linux)
app.commandLine.appendSwitch('enable-features', 'WebRTCPipeWireCapturer');
app.commandLine.appendSwitch('enable-webrtc-pipewire-capturer');

// Enable Windows loopback audio capture
// Note: Windows loopback audio is enabled via setDisplayMediaRequestHandler callback
// with audio: "loopback" - no additional command line switches needed

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      preload: join(__dirname, "../preload.js"),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false
    },
    titleBarStyle: "hiddenInset",
    backgroundColor: "#1e1e1e"
  });

  mainWindow.loadURL("https://fcc5wl41-3000.aue.devtunnels.ms");

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

// Handle uncaught exceptions to prevent crashes
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  // Don't crash the app - log and continue
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  // Don't crash the app - log and continue
});

app.whenReady().then(() => {
  // Register IPC handlers
  try {
    registerScreenShareHandler();
    registerAudioHandler();
    registerPermissionsHandler();
  } catch (error) {
    console.error("Error registering IPC handlers:", error);
    // Continue anyway - some handlers might still work
  }

  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

