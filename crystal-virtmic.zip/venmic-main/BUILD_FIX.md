# Build Fix for Rohrkabel Missing <variant> Header

## Problem

When building venmic, you may encounter this error:

```
error: 'variant' is not a member of 'std'
note: 'std::variant' is defined in header '<variant>'; this is probably fixable by adding '#include <variant>'
```

This is because rohrkabel 7.0 uses `std::variant` but doesn't include the `<variant>` header.

## Automatic Fix

The CMakeLists.txt now includes an automatic patch that should fix this issue. However, if the automatic patch doesn't work (e.g., if the file is downloaded after configure time), you can manually patch it.

## Manual Fix

If the automatic patch fails, you can manually fix it:

1. **Find the rohrkabel source file**:
   ```bash
   find build -name "core.cpp" -path "*/rohrkabel-src/src/core.cpp"
   ```

2. **Edit the file** and add `#include <variant>` after the first include:
   ```cpp
   #include <pipewire/pipewire.h>
   #include <variant>  // Add this line
   ```

3. **Or use sed** to patch it automatically:
   ```bash
   find build -name "core.cpp" -path "*/rohrkabel-src/src/core.cpp" -exec sed -i '/#include <pipewire\/pipewire\.h>/a #include <variant>' {} \;
   ```

## Using the Patch Script

You can also run the patch script manually:

```bash
# After running cmake configure
cmake -P cmake/patch_rohrkabel.cmake

# Or if using cmake-js, after it downloads dependencies:
cd build
cmake -P ../cmake/patch_rohrkabel.cmake
```

## For npm/cmake-js Builds

When building with `npm install` (which uses cmake-js), the dependencies are downloaded during the build phase. The automatic patch should work, but if it doesn't:

1. **Let the build fail** (it will download rohrkabel first)
2. **Run the patch script** (easiest method):
   ```bash
   ./patch_rohrkabel.sh
   ```
   
   Or manually:
   ```bash
   find . -name "core.cpp" -path "*/rohrkabel-src/src/core.cpp" -exec sed -i '/#include <pipewire\/pipewire\.h>/a #include <variant>' {} \;
   ```
3. **Continue the build**:
   ```bash
   npm install
   ```

## Verification

After patching, verify the fix:

```bash
grep -A 1 "pipewire/pipewire.h" build/_deps/rohrkabel-src/src/core.cpp
```

You should see:
```cpp
#include <pipewire/pipewire.h>
#include <variant>
```

## Permanent Fix

This is a bug in rohrkabel 7.0. The proper fix would be to:
1. Report the issue to the rohrkabel repository
2. Use a newer version of rohrkabel when available
3. Or fork rohrkabel and apply the fix

For now, this workaround should allow venmic to build successfully.

