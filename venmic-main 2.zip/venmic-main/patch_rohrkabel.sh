#!/bin/bash
# Script to patch rohrkabel core.cpp to add missing <variant> header
# This fixes the build error: 'variant' is not a member of 'std'

set -e

# Find the rohrkabel core.cpp file
CORE_CPP=$(find . -name "core.cpp" -path "*/rohrkabel-src/src/core.cpp" 2>/dev/null | head -1)

if [ -z "$CORE_CPP" ]; then
    echo "Error: Could not find rohrkabel core.cpp file"
    echo "Make sure you've run cmake configure or npm install first"
    exit 1
fi

echo "Found rohrkabel core.cpp at: $CORE_CPP"

# Check if already patched
if grep -q "#include <variant>" "$CORE_CPP"; then
    echo "File already patched, skipping..."
    exit 0
fi

# Check if std::variant is used (meaning we need to patch)
if ! grep -q "std::variant" "$CORE_CPP"; then
    echo "File doesn't use std::variant, no patch needed"
    exit 0
fi

# Patch the file: add #include <variant> after #include <pipewire/pipewire.h>
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS uses BSD sed
    sed -i '' '/#include <pipewire\/pipewire\.h>/a\
#include <variant>
' "$CORE_CPP"
else
    # Linux uses GNU sed
    sed -i '/#include <pipewire\/pipewire\.h>/a #include <variant>' "$CORE_CPP"
fi

echo "Successfully patched rohrkabel core.cpp"
echo "You can now continue building venmic"

