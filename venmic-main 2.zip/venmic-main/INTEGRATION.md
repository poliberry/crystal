# Venmic Integration Guide for Crystal Electron

This document describes the refactored venmic integration for use with Crystal Electron.

## Changes Made

### 1. Configurable Virtual Microphone Name
- Added `setVirtualMicName()` and `getVirtualMicName()` methods to the PatchBay class
- Virtual mic name can now be set to "crystal-screen-share" instead of the default "vencord-screen-share"
- The name is set before creating the virtual microphone

### 2. Singleton Instance Export
- The addon now exports a singleton instance as both `default` and `instance` properties
- This makes it easier to use without needing to instantiate the class manually
- The underlying C++ code still uses a singleton pattern internally

### 3. Updated TypeScript Definitions
- Added `setVirtualMicName()` and `getVirtualMicName()` to the PatchBay interface
- Added exports for `default` and `instance` singleton instances

## Building Venmic

### Prerequisites
- CMake 3.21 or higher
- C++20 compatible compiler (GCC 10+, Clang 12+)
- Node.js 14.15 or higher
- PipeWire development libraries
- PulseAudio development libraries

### Build as Node.js Addon (for Electron)

```bash
cd venmic-main
pnpm install
# or
npm install
```

This will:
1. Use `pkg-prebuilds` to check for prebuilt binaries
2. If not available, use `cmake-js` to compile the native addon
3. Build with `venmic_addon=ON` flag

### Manual Build

```bash
cd venmic-main
pnpm install
pnpm run cpcmds  # Generate compile commands
# The addon will be built in build/Release/venmic-addon.node
```

## Usage in Crystal Electron

The refactored `venmic.ts` integration file handles:

1. **Loading the module**: Dynamically requires `@vencord/venmic`
2. **Getting the instance**: Tries `default`, then `instance`, then creates new instance
3. **Setting virtual mic name**: Sets to "crystal-screen-share" before use
4. **System audio capture**: Uses empty `include` array with `only_default_speakers=true`
5. **Selective capture**: Uses `include` array with specific nodes

### API Usage

```typescript
import { listAudioSources, createVirtualMic, stopVirtualMic } from './audio/venmic';

// List available audio sources
const sources = await listAudioSources();

// Start system audio capture
await createVirtualMic({
  mode: "system",
  exclude: [] // Optional: exclude specific apps
});

// Start selective audio capture
await createVirtualMic({
  mode: "selective",
  include: [
    { "node.name": "Firefox" },
    { "application.name": "Chrome" }
  ]
});

// Stop capture
await stopVirtualMic();
```

## Virtual Microphone Name

The virtual microphone is created with the name "crystal-screen-share" which matches what Crystal Electron expects. This can be changed by calling `setVirtualMicName()` before creating the virtual mic.

## Troubleshooting

### Module not loading
- Ensure `@vencord/venmic` is installed: `npm install @vencord/venmic`
- Check that native addon compiled successfully
- On Linux, ensure PipeWire and PulseAudio development libraries are installed

### Virtual mic not appearing
- Check PipeWire is running: `systemctl --user status pipewire`
- Verify PipeWire detection: `PatchBay.hasPipeWire()` should return `true`
- Check logs for errors in `~/.local/state/venmic/venmic.log` (if `VENMIC_ENABLE_LOG` is set)

### Audio not capturing
- Ensure applications are playing audio
- Check that `only_default_speakers` is set correctly
- Verify links are being created (check logs)

## Testing

To test the integration:

1. Build venmic: `cd venmic-main && pnpm install`
2. Install in crystal-electron: `cd crystal-electron && npm install`
3. Run the app: `npm run dev`
4. Try screen sharing with audio capture

## Notes

- The virtual microphone name is set to "crystal-screen-share" to match Crystal Electron's expectations
- The singleton pattern ensures only one PatchBay instance exists
- All PipeWire operations happen in a background thread to avoid blocking

